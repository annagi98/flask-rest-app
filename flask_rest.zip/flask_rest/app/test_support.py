from .models import db, AllQuestions, UserKnowledgeBase, UserTrackingScore
from flask import jsonify


def delete_tracking_score_f():
    UserTrackingScore.query.delete()
    db.session.commit()
    return jsonify({'message': 'all from tracking score deleted'})


def delete_knowledge_base_f():
    UserKnowledgeBase.query.delete()
    db.session.commit()
    return jsonify({'message': 'all from knowledge base deleted'})


def delete_all_questions_f():
    AllQuestions.query.delete()
    db.session.commit()
    return jsonify({'message': 'all questions deleted'})


def sum_of_time_spent_learning_f(user_id):
    all_recalls_for_question = db.session.query(UserTrackingScore).filter(UserTrackingScore.user_id == user_id).all()
    time_spent = len(all_recalls_for_question) * 10
    return jsonify({'time_spent' :time_spent})


def rate_of_learning_f(user_id):
    list_of_levels = list_of_knowledge_lvls(user_id)
    all_count = len(list_of_levels)
    known_count = sum((x != 0) for x in list_of_levels)
    return jsonify({'all_count' : all_count,
                    'known_count' : known_count})


def calculate_knowledge_lvl_ratios_f(user_id):
    all_recalls_for_question = db.session.query(UserKnowledgeBase).filter(UserKnowledgeBase.user_id == user_id).all()
    list_of_levels = []
    for item in all_recalls_for_question:
        list_of_levels.append(item.knowledge_lvl)
    max_knowledge_lvl = max(list_of_levels)
    counted_all = len(list_of_levels)
    counts_per_lvl = []
    ratios_per_lvl = []
    for knowledge_lvl in range(0, max_knowledge_lvl+1):
        counts_this_lvl = list_of_levels.count(knowledge_lvl)
        counts_per_lvl.append(counts_this_lvl)
        ratios_per_lvl.append(counts_this_lvl/counted_all)

    dictionary = dict()
    keys = range(max_knowledge_lvl+1)
    values = ratios_per_lvl
    for i in keys:
        dictionary[i] = values[i]
    return jsonify(dictionary)


def list_of_knowledge_lvls(user_id):
    all_recalls_for_question = db.session.query(UserKnowledgeBase).filter(UserKnowledgeBase.user_id == user_id).all()
    list_of_levels = []
    for item in all_recalls_for_question:
        list_of_levels.append(item.knowledge_lvl)
    return list_of_levels
