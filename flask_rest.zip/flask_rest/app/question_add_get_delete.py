from .schemas import AllQuestionsSchema, KnowledgeBaseSchema
from .models import db, AllQuestions, UserKnowledgeBase
from flask import request, jsonify

question_schema = AllQuestionsSchema()
knowledge_base_schema = KnowledgeBaseSchema

def add_new_question_f():
    set_name = request.json['set_name']
    question = request.json['question']
    answer = request.json['answer']

    new_question = AllQuestions(set_name, question, answer)
    db.session.add(new_question)
    db.session.commit()
    return question_schema.jsonify(new_question)


def get_question_f(id):
    one_question = AllQuestions.query.get(id)
    return question_schema.jsonify(one_question)


def delete_question_f(id):
    question_to_delete = AllQuestions.query.get(id)
    db.session.delete(question_to_delete)
    db.session.commit()
    return question_schema.jsonify(question_to_delete)


def get_all_sets_f():
    all_questions = AllQuestions.query.all()
    list_set = []
    for element in all_questions:
        if element.set_name not in list_set:
            list_set.append(element.set_name)

    return jsonify({'all_sets': list_set})


def list_all_sets_test_f():
    all_questions = AllQuestions.query.all()
    list_set = []
    for element in all_questions:
        if element.set_name not in list_set:
            list_set.append(element.set_name)

    return jsonify({'all_sets': list_set})