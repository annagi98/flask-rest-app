from .models import db, AllQuestions, UserKnowledgeBase, NewQuestionsForUser
from .question_add_get_delete import get_question_f
from .schemas import KnowledgeBaseSchema, NewQuestionsForUserSchema
from .time_functions import just_get_time
from flask import request, jsonify
import random

new_question_for_user_schema = NewQuestionsForUserSchema()
knowledge_base_log = KnowledgeBaseSchema()


def learn_new_word_f(user_id, set_name):
    all_from_specific_set = NewQuestionsForUser.query.filter(((NewQuestionsForUser.set_name == set_name) & (NewQuestionsForUser.already_learning == 0))& (NewQuestionsForUser.user_id == user_id))
    list_of_ids = []
    for element in all_from_specific_set:
        list_of_ids.append(element.get_question_id())
    one_question_id = random.choice(list_of_ids)
    return get_question_f(one_question_id)


def add_as_already_learning_f(user_id, set_name, question_id):
    all_record = NewQuestionsForUser.query.filter((NewQuestionsForUser.user_id == user_id) & ((NewQuestionsForUser.set_name == set_name) & (NewQuestionsForUser.question_id == question_id))).first()
    record_id = all_record.get_record_id()
    already_learning_question = NewQuestionsForUser.query.get(record_id)
    already_learning_question.already_learning = 1 #changing status to already known
    db.session.commit()
    return new_question_for_user_schema.jsonify(already_learning_question)


def should_questions_be_added_f(user_id, set_name):
    all_questions_to_learn_for_selected_user = NewQuestionsForUser.query.filter(
        (NewQuestionsForUser.set_name == set_name) & (
                    NewQuestionsForUser.user_id == user_id)).first()
    if all_questions_to_learn_for_selected_user:
        return jsonify({'should_be_added': 'no', 'ids_of_questions_to_be_added': []})
    else:
        question_ids_to_be_added = []
        questions_to_be_added = AllQuestions.query.filter(AllQuestions.set_name == set_name)
        for question in questions_to_be_added:
            question_ids_to_be_added.append(question.get_question_id())
        return jsonify({'should_be_added': 'yes', 'ids_of_questions_to_be_added': question_ids_to_be_added})


def test_add_to_userknowledgebase_f(subjective_easiness=1, user_id=1, set_name="work"):
    question_id = request.json['question_id']
    day_of_presentation = request.json['day_of_presentation']
    knowledge_lvl = request.json['knowledge_lvl']
    user_knowledge_base_log = UserKnowledgeBase(user_id, set_name, question_id, day_of_presentation, knowledge_lvl)
    db.session.add(user_knowledge_base_log)
    db.session.commit()
    return knowledge_base_log.jsonify(user_knowledge_base_log)


def add_to_knowledge_base_new_f(user_id, question_id, set_name):
    day_of_presentation = just_get_time() + 1
    knowledge_lvl = 0
    subjective_easiness = 1
    kb_log = UserKnowledgeBase(user_id, set_name, question_id, day_of_presentation, knowledge_lvl, subjective_easiness)
    db.session.add(kb_log)
    db.session.commit()
    return knowledge_base_log.jsonify(kb_log)




