from .schemas import AllQuestionsSchema, KnowledgeBaseSchema, TrackingScoreSchema
from .models import db, AllQuestions, UserKnowledgeBase, UserTrackingScore
from .test_helper_functions import get_last_recall, choose_question_to_show, calculate_next_date
from .time_functions import just_get_time

question_schema = AllQuestionsSchema()
tracking_score_log = TrackingScoreSchema()
knowledge_base_log = KnowledgeBaseSchema()


def return_question_for_user(user_id, set_name, random):
    id_of_question_chosen_by_algorithm, knowledge_base_record_id, knowledge_lvl_old = choose_question_to_show(user_id, set_name, random)
    question_for_user = db.session.query(AllQuestions).filter(AllQuestions.question_id == id_of_question_chosen_by_algorithm).first()
    json_schema = question_schema.dump(question_for_user)
    last_recall = get_last_recall(user_id, id_of_question_chosen_by_algorithm)

    all_recalls = db.session.query(UserTrackingScore).filter(UserTrackingScore.user_id == user_id).filter(UserTrackingScore.question_id == id_of_question_chosen_by_algorithm).all()
    all_recalls_count = len(all_recalls)

    new_row_json = {"record_id_knowledge_base": knowledge_base_record_id,
                    "old_knowledge_lvl": knowledge_lvl_old,
                    "last_recall": last_recall,
                    "all_recalls": all_recalls_count}
    json_schema.update(new_row_json)
    return json_schema


def add_to_track_score_f(user_id, question_id, was_good):
    subjective_easiness = 1
    day_today = just_get_time()
    user_tracking_score_log = UserTrackingScore(user_id, question_id, day_today, was_good, subjective_easiness)
    db.session.add(user_tracking_score_log)
    db.session.commit()
    return tracking_score_log.jsonify(user_tracking_score_log)


def update_knowledge_base_for_user_f(record_id, was_good):
    day_today = just_get_time()
    just_answered_question = UserKnowledgeBase.query.get(record_id)
    if was_good == "0":
        when_to_present = day_today + 1
        just_answered_question.day_of_presentation = when_to_present
        just_answered_question.knowledge_lvl = 0

    else:
        old_knowledge_lvl = just_answered_question.get_knowledge_lvl()
        new_knowledge_lvl = old_knowledge_lvl + 1
        just_answered_question.knowledge_lvl = new_knowledge_lvl
       # level_increment = [5,5,5,5,5,5,5]
       # level_increment = [1,1,1,1,1,1,1]
        level_increment = [1, 3, 7, 10, 14, 20, 30]
        when_to_present = calculate_next_date(new_knowledge_lvl, level_increment)
        just_answered_question.day_of_presentation = day_today + when_to_present
    db.session.commit()
    return knowledge_base_log.jsonify(just_answered_question)


def update_knowledge_base_for_user_test_f(record_id, was_good, level_increment_):
    day_today = just_get_time()
    just_answered_question = UserKnowledgeBase.query.get(record_id)
    if was_good == "0":
        when_to_present = day_today + 1
        just_answered_question.day_of_presentation = when_to_present
        just_answered_question.knowledge_lvl = 0

    else:
        old_knowledge_lvl = just_answered_question.get_knowledge_lvl()
        new_knowledge_lvl = old_knowledge_lvl + 1
        just_answered_question.knowledge_lvl = new_knowledge_lvl
        level_increment = [1, 3, 7, 10, 14, 20, 30]
        if level_increment_==1:
            level_increment = [1,1,1,1,1,1,1]
        if level_increment_ == 5:
            level_increment = [5,5,5,5,5,5,5]
        if level_increment_ == 2:
            level_increment= [1,2,4,8,16,32,64]
        if level_increment_ == 3:
            level_increment =  [1, 3, 7, 10, 14, 20, 30]

        when_to_present = calculate_next_date(new_knowledge_lvl, level_increment)
        just_answered_question.day_of_presentation = day_today + when_to_present
    db.session.commit()
    return knowledge_base_log.jsonify(just_answered_question)

