from . import db
from flask_login import UserMixin

class AllQuestions(db.Model):
    question_id = db.Column(db.Integer, primary_key=True)
    set_name = db.Column(db.String(70))
    question = db.Column(db.String(70))
    answer = db.Column(db.String(70))

    def __init__(self, set_name, question, answer):
        self.set_name = set_name
        self.question = question
        self.answer = answer

    def get_question_id(self):
        id = self.question_id
        return id

    def get_question(self):
        return self.question

    def get_answer(self):
        return self.answer



class UserKnowledgeBase(db.Model):
    record_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    set_name = db.Column(db.String(70))
    question_id = db.Column(db.Integer)
    day_of_presentation = db.Column(db.Integer)
    knowledge_lvl = db.Column(db.Integer)
    subjective_easiness = db.Column(db.Integer)

    def __init__(self, user_id, set_name, question_id, day_of_presentation, knowledge_lvl, subjective_easiness=1):
        self.user_id = user_id
        self.set_name = set_name
        self.question_id = question_id
        self.day_of_presentation = day_of_presentation
        self.knowledge_lvl = knowledge_lvl
        self.subjective_easiness = subjective_easiness

    def get_question_id(self):
        question_id = self.question_id
        return question_id

    def get_record_id(self):
        record_id = self.record_id
        return record_id

    def get_knowledge_lvl(self):
        knowledge_lvl = self.knowledge_lvl
        return knowledge_lvl

    def get_days_of_presentation(self):
        return self.day_of_presentation

    def set_knowledge_lvl(self, new_knowledge_lvl):
        self.knowledge_lvl = new_knowledge_lvl

    def set_day_of_presentation(self, new_day):
        self.day_of_presentation = new_day


class UserTrackingScore(db.Model): #for tracking user progress
    record_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    question_id = db.Column(db.Integer)
    day_of_answer = db.Column(db.Integer)
    is_good = db.Column(db.Integer)
    subjective_easiness = db.Column(db.Integer)

    def __init__(self, user_id, question_id, day_of_answer, is_good, subjective_easiness=1):
        self.user_id = user_id
        self.question_id = question_id
        self.day_of_answer = day_of_answer
        self.is_good = is_good
        self.subjective_easiness = subjective_easiness

    def get_day_of_answer(self):
        day_of_answer = self.day_of_answer
        return day_of_answer

class TimeNow(db.Model):
    record_id = db.Column(db.Integer, primary_key=True)
    time_now = db.Column(db.Integer)

    def __init__(self, time_now):
        self.time_now = time_now

    def get_time(self):
        time_now = self.time_now
        return time_now

class NewQuestionsForUser(db.Model):
    record_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    set_name = db.Column(db.Integer)
    question_id = db.Column(db.Integer)
    already_learning = db.Column(db.Integer)

    def __init__(self, user_id, set_name, question_id, already_learning):
        self.user_id = user_id
        self.set_name = set_name
        self.question_id = question_id
        self.already_learning = already_learning

    def get_question_id(self):
        q_id = self.question_id
        return q_id

    def get_record_id(self):
        r_id = self.record_id
        return r_id

    def set_already_learning(self, learning):
        self.already_learning = learning


class User(db.Model, UserMixin):
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(70))
    password = db.Column(db.String(70))
    email = db.Column(db.String(70))

    def __init__(self, username, password, email):
        self.username = username
        self.password = password
        self.email = email

    def get_user_id(self):
        return (self.user_id)

    def get_username(self):
        return self.username

    def get_password(self):
        return self.password

    def set_password(self, password_n):
        self.password = password_n

