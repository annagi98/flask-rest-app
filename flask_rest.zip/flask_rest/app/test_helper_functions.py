from .models import db, UserKnowledgeBase, UserTrackingScore
from .time_functions import calculate_time_impact
from numpy.random import choice


def get_last_recall(user_id, question_id):
    all_recalls_for_question = db.session.query(UserTrackingScore).filter(UserTrackingScore.question_id == question_id).filter(UserTrackingScore.user_id == user_id).all()
    list_of_dates = []
    for recall in all_recalls_for_question:
        list_of_dates.append(recall.get_day_of_answer())

    if not list_of_dates:
        last_recall = 0
    else:
        last_recall = max(list_of_dates)
    return last_recall


def choose_question_to_show(user_id, set_name, random):
    available_questions_for_user = db.session.query(UserKnowledgeBase).filter(UserKnowledgeBase.user_id == user_id).filter(UserKnowledgeBase.set_name == set_name).filter(UserKnowledgeBase.knowledge_lvl != 6).all()  #prze all było limit(1). returns all question from specific set dla zbioru: (UserKnowledgeBase.set_name == set_name) & (UserKnowledgeBase.user_id == user_id)

    question_id = pick_question_id(available_questions_for_user, random)
    only_id = int(question_id)
    record_id, knowledge_lvl = from_userknowledgebase_get_recordid_knowledgelvl(only_id, user_id)
    return only_id, record_id, knowledge_lvl


def from_userknowledgebase_get_recordid_knowledgelvl(question_id, user_id):
    available_questions_for_user = db.session.query(UserKnowledgeBase).filter(UserKnowledgeBase.user_id == user_id).filter(UserKnowledgeBase.question_id == question_id).limit(1).all()
    record_id = available_questions_for_user[0].record_id
    knowledge_lvl = available_questions_for_user[0].knowledge_lvl
    return record_id, knowledge_lvl


def pick_question_id(rows, random):
    time_impact_all = []
    question_ids_all = []

    if random ==1:
        for row in rows:
            question_ids_all.append(row.question_id)
            id = random(question_ids_all)
    else:
        for row in rows:
            question_ids_all.append(row.question_id)
            time_impact = calculate_time_impact(row.day_of_presentation)
            time_impact_all.append(1 / time_impact)

        normalized_probabilities = sum_to_1(time_impact_all)
        draw = choice(question_ids_all, 1, p=normalized_probabilities)
        id = draw[0]

    return id


def sum_to_1(vector):
    sum_of_vector = sum(vector)
    new_vector = []
    for item in vector:
        new_vector.append(item/sum_of_vector)
    return new_vector


def calculate_next_date(new_knowledge_lvl, level_increment):
    days_to_present = level_increment[new_knowledge_lvl]
    return days_to_present


