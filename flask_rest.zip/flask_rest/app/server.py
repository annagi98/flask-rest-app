from flask import render_template
from flask import current_app as app

from .learn_functions import should_questions_be_added_f, learn_new_word_f, add_as_already_learning_f, \
    test_add_to_userknowledgebase_f, add_to_knowledge_base_new_f
from .question_add_get_delete import add_new_question_f, delete_question_f, get_all_sets_f, list_all_sets_test_f
from .test_functions import return_question_for_user, add_to_track_score_f, update_knowledge_base_for_user_f, update_knowledge_base_for_user_test_f
from .test_support import delete_tracking_score_f, delete_knowledge_base_f, delete_all_questions_f, \
    sum_of_time_spent_learning_f, rate_of_learning_f, calculate_knowledge_lvl_ratios_f

from .time_functions import get_time_f, update_current_time, start_time_f
from .login_and_register import login_user_f, singup_post_f, logout_f


@app.route('/', methods=['GET'])
def index():
    return render_template('home.html')


@app.route('/test', methods=['GET'])
def test_question():
    return render_template('start_test.html')


@app.route('/learn', methods=['GET'])
def learn_question():
    return render_template('start_learn.html')


@app.route('/learn/set_name=<set_name1>', methods=['GET'])
def learn_question_s(set_name1):
    return render_template('start_learn.html', chosen_set_name=set_name1)


@app.route('/test/set_name=<set_name1>', methods=['GET'])
def test_question_s(set_name1):
    return render_template('start_test.html', chosen_set_name=set_name1)


@app.route('/select_set_learn', methods=['GET'])
def select_set_learn_question():
    return render_template('select_set_learn.html')


@app.route('/select_set_test', methods=['GET'])
def select_set_test_question():
    return render_template('select_set_test.html')


@app.route('/enter_new_question', methods=['GET'])
def enter_new_question():
    return render_template('enter_new_question.html')


@app.route('/signup', methods=['GET'])
def signup_page():
    return render_template('signup.html')


@app.route('/api/register', methods=['POST'])
def register():
    return singup_post_f()


@app.route('/login', methods=['GET'])
def login_page():
    return render_template('login.html')


@app.route('/api/login', methods=['POST'])
def login_post():
    return login_user_f()


@app.route('/api/logout', methods=['GET'])
def logout():
    return logout_f()


@app.route('/api/login', methods=['POST'])
def login_user():
    return login_user_f()


@app.route('/api/list_all_sets/learn', methods=['GET'])
def list_all_sets_learn():
    return get_all_sets_f()


@app.route('/api/list_all_sets/test', methods=['GET'])
def list_all_sets_test():
    return list_all_sets_test_f()


# API
@app.route('/api/question/new', methods=['Post']) # tests - mass adding new questions
def add_new_question():
    return add_new_question_f()


@app.route('/api/question/<id>', methods=['DELETE']) # tests - to delete all questions
def delete_question(id):
    return delete_question_f(id)


@app.route('/api/time/start', methods=['Post']) #only done once
def start_time():
    return start_time_f()


@app.route('/api/time/update/type_of_update=<day_zero_or_next>', methods=['Put']) #time update - when 0 restart time, if 1 go to next day
def change_time(day_zero_or_next):
    return update_current_time(day_zero_or_next)


@app.route('/api/learn/new_word/user_id=<user_id>/set_name=<set_name>', methods=['GET']) #get random question id from new question for user that was not chosen previously
def learn_new_word(user_id, set_name):
    return learn_new_word_f(user_id, set_name)


@app.route('/api/learn/word_not_new_anymore/user_id=<user_id>/set_name=<set_name>/question_id=<question_id>', methods=['PUT']) #learn - pytanie do nauki pokazane userowi 1. raz oznaczamy jako juz zadane
def update_word_as_already_learning(user_id, set_name, question_id):
    return add_as_already_learning_f(user_id, set_name, question_id)


@app.route('/api/test/get_question/set_name=<set_name>/user_id=<user_id>/is_random=<random>', methods=['GET']) #test, simulation
def get_question_from_chosen_set(user_id, set_name, random):
    return return_question_for_user(user_id, set_name, random)


@app.route('/api/test/post_to_track_score/<user_id>/<question_id>/<was_good>', methods=['POST'])
def add_question_to_track_score(user_id, question_id, was_good):
    return add_to_track_score_f(user_id, question_id, was_good)


@app.route('/api/test/add_to_knowledge_base', methods=['POST']) # do testow masowo, ok,learn - po pokazaniu pytania po raz 1., tests - mass adding to userknowledgebase
def test_add_to_userknowledgebase(subjective_easiness=1, user_id=1, set_name = "work"):
    return test_add_to_userknowledgebase_f(subjective_easiness, user_id, set_name)


@app.route('/api/learn/add_to_knowledge_base/set_name=<set_name>/user_id=<user_id>/question_id=<question_id>', methods=['POST']) # do learn - pytanie do nauki pokazane userowi 1. raz wrzucamy do knowledge base
def add_word_to_knowledge_base(user_id, question_id, set_name):
    return add_to_knowledge_base_new_f(user_id, question_id, set_name)


@app.route('/api/time/get_time', methods=['GET'])
def get_time():
    return get_time_f()


@app.route('/api/learn/update_knowledge_base/record_id=<record_id>/was_good=<was_good>', methods=['PUT'])
def update_knowledge_base(record_id, was_good):
    return update_knowledge_base_for_user_f(record_id, was_good)


@app.route('/api/test/update_knowledge_base/record_id=<record_id>/was_goo=<was_good>/<level_increment>', methods=['PUT'])
def update_knowledge_base_for_user_test(record_id, was_good, level_increment):
    return update_knowledge_base_for_user_test_f(record_id, was_good, level_increment)


@app.route('/api/tracking_score/delete_all', methods=['DELETE'])
def delete_tracking_score():
    return delete_tracking_score_f()


@app.route('/api/knowledge_base/delete_all', methods=['DELETE'])
def delete_knowledge_base():
    return delete_knowledge_base_f()


@app.route('/api/questions/delete_all', methods=['DELETE'])
def delete_all_questions():
    return delete_all_questions_f()


@app.route('/api/statistics/time_spent_learning/user_id=<user_id>', methods=['GET']) #return estimated time spent on learning in seconds
def get_time_spent_learning(user_id):
    return sum_of_time_spent_learning_f(user_id)


@app.route('/api/statistics/successful_learned_ratio/user_id=<user_id>',methods=['GET'])
def get_successful_learned_ratio(user_id):
    return rate_of_learning_f(user_id)


@app.route('/api/statistics/knowledge_lvl_ratios/user_id=<user_id>', methods=['GET'])
def get_knowledge_lvl_ratios(user_id):
    return calculate_knowledge_lvl_ratios_f(user_id)


@app.route('/api/learn/check_if_set_is_used_by_user/user_id=<user_id>/set_name=<set_name>', methods=['GET'])
def is_set_user_by_user(user_id, set_name):
    return should_questions_be_added_f(user_id, set_name)

