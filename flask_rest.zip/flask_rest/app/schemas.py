from . import ma



class AllQuestionsSchema(ma.Schema):
    class Meta:
        fields = ('question_id', 'set_name', 'question', 'answer')


class KnowledgeBaseSchema(ma.Schema):
    class Meta:
        fields = ('record_id', 'user_id', 'set_name', 'question_id', 'day_of_presentation', 'knowledge_lvl', 'subjective_easiness')


class TrackingScoreSchema(ma.Schema):
    class Meta:
        fields = ('record_id', 'user_id', 'question_id', 'day_of_answer', 'is_good', 'subjective_easiness')


class NewQuestionsForUserSchema(ma.Schema):
    class Meta:
        fields = ('record_id', 'user_id', 'set_name', 'question_id', 'already_learning')


class TimeSchema(ma.Schema):
    class Meta:
        fields = ('time_now',)


class UserSchema(ma.Schema):
    class Meta:
        fields = ('username', 'password', 'email')

