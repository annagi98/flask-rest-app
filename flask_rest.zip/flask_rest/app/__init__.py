from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_migrate import Migrate
from flask_bootstrap import Bootstrap

from flask_login import LoginManager


db = SQLAlchemy()
ma = Marshmallow()
migrate = Migrate(db)



def create_app():
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object('config.Config')

    db.init_app(app)
    bootstrap = Bootstrap(app)
   # login_manager = LoginManager(app)
    login_manager = LoginManager(app)
    login_manager.login_view = 'login_user'
    login_manager.init_app(app)

    from .models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))


    with app.app_context():
        from . import server
        db.create_all()
        return app
