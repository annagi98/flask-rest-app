from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import redirect

from .models import db, User
from flask import request, flash
from flask_login import login_user, current_user, logout_user


def login_user_f():
    email = request.form.get('email')
    password = request.form.get('password')

    user = User.query.filter_by(email=email).first()
    if not user:
        flash('This user does not exist. Please try again or sign up.')
        return redirect('/login')

    if not check_password_hash(user.password, password):
        flash('The password you entered is incorrect. Please try again.')
        return redirect('/login')

    login_user(user)
    if current_user.is_authenticated:
        return redirect('/')
    return redirect('/login')


def logout_f():
    logout_user()
    return redirect('/')

def singup_post_f():
    email = request.form.get('email')
    username = request.form.get('username')
    password = request.form.get('password')
    password2 = request.form.get('password2')

    user = User.query.filter_by(email=email).first()
    if user: #this email is already used
        return redirect('/signup')

    if password!=password2: #passwords should be identical
        return redirect('/signup')

    new_user = User(email=email, username=username, password=generate_password_hash(password, method='sha256'))
    db.session.add(new_user)
    db.session.commit()

    return redirect('/login')
