from .models import db, TimeNow
from .schemas import TimeSchema

from flask import jsonify

time_schema = TimeSchema()


def calculate_time_impact(day_of_presentation):
    time_now = just_get_time()
    time_impact = abs(day_of_presentation - time_now)
    if time_impact == 0:
        time_impact = 1
    return time_impact


def just_get_time():
    time_object = TimeNow.query.first()
    day_today = time_object.get_time()
    return day_today


def get_time_f():
    day_today = just_get_time()
    return jsonify({'time_now' : day_today})


def update_current_time(day_zero_or_next):
    time_obj = TimeNow.query.get(1)
    if day_zero_or_next == "0":
        new_time = 1
    else:
        old_time = time_obj.time_now
        new_time = old_time + 1
    time_obj.time_now = new_time
    db.session.commit()
    return time_schema.jsonify(time_obj)


def start_time_f():
    time_now = 1
    time_new = TimeNow(time_now)
    db.session.add(time_new)
    db.session.commit()
    return time_schema.jsonify(time_new)